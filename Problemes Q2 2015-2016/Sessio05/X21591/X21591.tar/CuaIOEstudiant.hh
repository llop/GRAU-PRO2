#ifndef QUEUE_IO_ESTUDIANT
#define QUEUE_IO_ESTUDIANT

#include <queue>
#include "Estudiant.hh"
using namespace std;

void LlegirCuaEstudiant(queue<Estudiant> &q);
void EscriureCuaEstudiant(queue<Estudiant> q);

#endif
