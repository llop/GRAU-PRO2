#ifndef PILA_IO_PARINT
#define PILA_IO_PARINT

#include <stack>
#include "ParInt.hh"
using namespace std;

void llegirPilaParInt(stack<ParInt> &p);
void escriurePilaParInt(stack<ParInt> p);

#endif
